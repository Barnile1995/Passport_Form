

<!DOCTYPE html>
<html>
<head>
	<title>form1</title>
</head>
<body>
	<h3 style="color: blue">PASSPORT APPLICATION - STAGE 1</h3>
	<H5 style="color: blue">BEFORE FILLING UP THE ONLINE APPLICATION FORM READ THE GUIDELINES CAREFULLY</H5>
	<p style="color: red">Fields marked with (*) are mandatory</p>
	<form action="sanitize.php" method="Post">
		<table>

			<h3>Passport Application Information </h3>
			<td colspan="2">Applying in:* </td>
			<td>
				<select>
					<option>-SELECT-</option>
					<option> Bangladesh </option>
					<option> India </option>
					<option> Nepal </option>					
				</select>  
			</td>
		</tr>

		<tr>
			<td>Application Type: NEW APPLICATION </td>
		</tr>

		<tr>
			<td colspan="2">Passport Type:* </td>
			<td>
				<select>
					<option> -SELECT- </option>
					<option> Genaral </option>
					<option> Civil </option>					
				</select>  
			</td>
		</tr>

		<tr>
			<td rowspan="2">Delivary Type: </td>
			<td colspan="2"> <input type="radio" name="dt"> Regular </td>
		</tr>
		<tr>
			<td colspan="2"> <input type="radio" name="dt"> Express	</td>
		</tr>

		<tr>
			<td> <h4> Personal Information </h4> </td>
		</tr>

		<tr>
			<td colspan="2">Name of applicant:* </td>
			<td> <input type="text" name="apli_name" required=""> </td>
		</tr>

		<tr>
			<td colspan="2">First Part (Given Name): </td>
			<td> <input type="text" name="fn" required=""></td>
		</tr>

		<tr>
			<td colspan="2">Second Part (Surname): </td>
			<td> <input type="text" name="sn" required=""></td>
		</tr>

		<tr>
			<td>Guradian <input type="checkbox" name="gcb"> "Tick" only if Applicant is legally adapted</td>
		</tr>

		<tr>
			<td colspan="2">Father's name:* </td>
			<td> <input type="text" name="fathern" required=""></td>
		</tr>

		<tr>
			<td colspan="2">Father's Nationality:* </td>
			<td>
				<select name ='tt' required="">
					<option> -SELECT- </option>
					<option> BANGLADESHI </option>
					<option> INDIAN </option>
					<option> NEPALIAN </option>					
				</select>  
			</td>
		</tr>

		<tr>
			<td colspan="2">Father's Profession:* </td>
			<td>
				<select>
					<option> -SELECT- </option>
					<option> BUSINESSMAN </option>
					<option> DRIVER </option>					
				</select>  
			</td>
		</tr>			

		<tr>
			<td colspan="2">Mother's name:* </td>
			<td> <input type="text" name="mothern" required=""></td>
		</tr>

		<tr>
			<td colspan="2">Mother's Nationality:* </td>
			<td>
				<select>
					<option> -SELECT- </option>
					<option> BANGLADESHI </option>
					<option> INDIAN </option>
					<option> NEPALIAN </option>					
				</select>  
			</td>
		</tr>

		<tr>
			<td colspan="2"> Mother's Profession:* </td>
			<td>
				<select>
					<option> -SELECT- </option>
					<option> BUSINESSMAN </option>
					<option> HOUSEWIFE </option>					
				</select>  
			</td>
		</tr>	

		<tr>
			<td colspan="2">Spouse's name: </td>
			<td> <input type="text" name="spousen"></td>
		</tr>

		<tr>
			<td colspan="2">Spouse's Nationality: </td>
			<td>
				<select>
					<option>-SELECT-</option>
					<option> BANGLADESHI </option>
					<option> INDIAN </option>
					<option> NEPALIAN </option>					
				</select>  
			</td>
		</tr>

		<tr>
			<td colspan="2">Spouse's Profession: </td>
			<td>
				<select>
					<option> -SELECT- </option>
					<option> BUSINESSMAN </option>
					<option> HOUSEWIFE </option>					
				</select>  
			</td>
		</tr>			

		<tr>
			<td colspan="2">Marital Status:* </td>
			<td>
				<select>
					<option> -SELECT- </option>
					<option> MARRIED </option>
					<option> UNMARRIED </option>					
				</select>  
			</td>
		</tr>	

		<tr>
			<td colspan="2">Applicant's Profession:* </td>
			<td>
				<select>
					<option> -SELECT- </option>
					<option> STUDENT </option>
					<option> BUSINESSMAN </option>					
				</select>  
			</td>
		</tr>	

		<tr>
			<td colspan="2">Country of Birth:* </td>
			<td>
				<select>
					<option> -SELECT- </option>
					<option> BANGLADESH </option>
					<option> OTHER </option>					
				</select>  
			</td>
		</tr>	

		<tr>
			<td colspan="2">Birth District:* </td>
			<td>
				<select>
					<option> -SELECT- </option>
					<option> DHAKA </option>
					<option> NARAYANGANJ </option>					
				</select>  
			</td>
		</tr>






		<tr> 
			<td colspan="2">Date of Birth:* </td>
			<td><input type="text" name="dob"> </td> 
		</tr>

		<tr>
			<td rowspan="4">Gender:* </td>
		</tr>
		<tr>
			<td colspan="2"> <input type="radio" name="nn"> Male </td>
		</tr>
		<tr>
			<td colspan="2"> <input type="radio" name="nn"> Female	</td>
		</tr>
		<tr>
			<td colspan="2"> <input type="radio" name="nn"> Others </td>
		</tr>

		<tr>
			<td colspan="2"> Birth ID No:* </td>
			<td> <input type="text" name="birthid"></td>
		</tr>

		<tr>
			<td colspan="2"> National ID No: </td>
			<td> <input type="text" name="nid"></td>
		</tr>

		
		<tr>
			<td colspan="2"> Tax ID No: </td>
			<td> <input type="text" name="taxid"></td>
		</tr>

		<tr>
			<td colspan="2"> Height:* </td>
			<td> <input type="text" name=""> cm <input type="text" name=""> inch</td>
		</tr>


		<tr>						
			<td colspan="2">Religion:* </td>
			<td>
				<select>
					<option>-SELECT-</option>
					<option> MUSLIM </option>
					<option> HINDU </option>
					<option> OTHERS </option>					
				</select>  
			</td>
		</tr>
		
		<tr>
			<td colspan="2"> Email:* </td>
			<td> <input type="text" name="email"></td>
		</tr>

		<tr>
			<td>
				<h3>Citizenship Information</h3>
			</td>
		</tr>
		

		<tr>						
			<td colspan="2">Nationality:* </td>
			<td>
				<select name="nt">
					<option>-SELECT-</option>
					<option> BANGLADESHI </option>
					<option> INDIAN </option>
					<option> OTHERS </option>					
				</select>  
			</td>
		</tr>

		<tr>						
			<td colspan="2">Citizenship Status:* </td>
			<td>
				<select>
					<option>-SELECT-</option>
					<option> BIRTH </option>
					<option> OTHERS </option>					
				</select>  
			</td>
		</tr>

		<tr>
			<td rowspan="2">Dual Citizenship:* </td>
			<td colspan="2"> <input type="radio" name="dc"> yes </td>
		</tr>
		<tr>
			<td colspan="2"> <input type="radio" name="dc"> no	</td>
		</tr>

		<tr>
			<td>
				<h3>Present Address</h3>
			</td>
		</tr>

		<tr>
			<td colspan="2"> Village/House: </td>
			<td> <input type="text" name="pvh"></td>
		</tr>

		<tr>
			<td colspan="2"> Road/Block/Sector: </td>
			<td> <input type="text" name="prbs"></td>
		</tr>

		<tr>						
			<td colspan="2">District:* </td>
			<td>
				<select>
					<option>-SELECT-</option>
					<option> DHAKA </option>
					<option> OTHERS </option>					
				</select>  
			</td>
		</tr>

		<tr>
			<td colspan="2"> Police Station:* </td>
			<td> <input type="text" name="pps"></td>
		</tr>

		<tr>
			<td colspan="2"> Post Office: </td>
			<td> <input type="text" name="ppo"></td>
		</tr>

		<tr>
			<td>
				<h3>Permanent Address</h3>
			</td>
		</tr>

		<tr>
			<td> <input type="checkbox" name=""> Same as above </td>
		</tr>

		<tr>
			<td colspan="2"> Village/House: </td>
			<td> <input type="text" name="permvh"></td>
		</tr>

		<tr>
			<td colspan="2"> Road/Block/Sector: </td>
			<td> <input type="text" name="permrbs"></td>
		</tr>

		<tr>						
			<td colspan="2">District:* </td>
			<td>
				<select>
					<option>-SELECT-</option>
					<option> DHAKA </option>
					<option> OTHERS </option>					
				</select>  
			</td>
		</tr>

		<tr>
			<td colspan="2"> Police Station:* </td>
			<td> <input type="text" name="permps"></td>
		</tr>

		<tr>
			<td colspan="2"> Post Office: </td>
			<td> <input type="text" name="permpo"></td>
		</tr>


		<tr> <!-- Submit/register & reset button-->
			<td colspan="2"> 
			<input type="submit" name="submit" value="SAVE NOW & CONTINUE IN THE FUTURE"> 
			<input type="submit" name="submit" value="SAVE & NEXT"> 
			</td>
		</tr>
		</table>
	</form>

</body>
</html>