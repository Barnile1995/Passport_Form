<!DOCTYPE html>
<html>
<head>
	<title>Stage 3</title>
</head>
<body>
<form action="sanitize.php">

	<table>
		<tr>
			<td colspan="4">
				<h3 style="color: blue">Payment Information</h3>
			</td>
			
		</tr>
		<tr>
				<td rowspan="3">Payment Type:</td>
				<td> <input type="radio" name="himu">Online
				</td>				
			</tr>

			<tr>
				<td>
					<input type="radio" name="himu">Non-online
				</td>
			</tr>
		<tr><td></td></tr>

		<tr>
			<td><input type="checkbox" name=""> Skip Payment</td>
			<td></td>
		</tr>
		<tr>
				<td >Date of Payment: </td>
				<td> <input type="text" name="" placeholder=""> </td>
			</tr>
		<tr>
				<td >Receipt No.: </td>
				<td> <input type="text" name="" placeholder=""> </td>
			</tr>
		<tr>
				<td >Name of Bank:</td>
				<td> 
					<select name="">
						<option>-SELECT-</option>
						<option>CITY</option>
						<option>JAMUNA</option>
						<option>BANK ASIA</option>
						<option>NATIONAL</option>
						<option>SOUTHEAST</option>
					</select> 
				</td>
			</tr>
			<tr>
				<td >Name of Branch:</td>
				<td> 
					<select name="">
						<option>PRINCIPAL</option>
						<option>MOTIJHEEL</option>
						<option>GULSHAN</option>
						<option>BANANI</option>
						<option>DHANMONDI</option>
						<option>FARMGATE</option>
					</select> 
				</td>
			</tr>
			<tr> 
				<td colspan="7"></td>
				<td >
				<input type="submit" name="" value="Previous Page"> 
				<input type="submit" name="" value="Save & Next"> 
				</td>
			</tr>
		</table>
		
</form>
</body>
</html>




			