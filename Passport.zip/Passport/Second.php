<!DOCTYPE html>
<html>
<head>
	<title>Stage 2</title>
</head>
<body>
	
<form action="sanitize.php">
	<table>
		<tr>
			<td colspan="4">
				<h3 style="color: blue">Applicant contact Information</h3>
			</td>
			<td colspan="3">
				<h3 style="color: blue">Old Passport Information</h3>
			</td>
		</tr>
		<tr> <!-- Dropdown box-->
				<td >Office no:</td>
				<td colspan="3"> 
					<input type="text" name="" placeholder=""> 
				</td>
				<td>
					Passport No.:
				</td>
				<td colspan="3"> 
					<input type="text" name="" placeholder=""> 
				</td>


			</tr>

			<tr> <!-- Dropdown box-->
				<td >Residance No. :</td>
				<td colspan="3"> 
					<input type="text" name="" placeholder=""> 
				</td>
				<td>
					Place of Issue.:
				</td>
				<td colspan="3"> 
					<input type="text" name="" placeholder=""> 
				</td>
			</tr>

			<tr> <!-- Dropdown box-->
				<td >Mobile No. :</td>
				<td colspan="3"> 
					<input type="text" name="" placeholder=""> 
				</td>
				<td>
					Date of Issue.:
				</td>
				<td colspan="3"> 
					<input type="text" name="" placeholder=""> 
				</td>
			</tr>

			<tr> <!-- Dropdown box-->
				<td ></td>
				<td colspan="3"> </td>
				<td>
					Re-Issue Reason:
				</td>
				<td>
					<select>
						<option> -SELECT- </option>
						<option> JANUARY </option>
						<option> FEBRUARY </option>	
						<option> MARCH </option>
						<option> APRIL </option>
						<option> MAY </option>
						<option> JUNE </option>
						<option> JULY </option>
						<option> AUGUST </option>
						<option> SEPTEMBER </option>
						<option> OCTOBER </option>	
						<option> NOVEMBER </option>
						<option> DECEMBER </option>			
					</select>  
				</td>
			</tr>
	</table>

	<table>
		<tr>
			<td colspan="4">
				<h3 style="color: blue">Emergency Information Contact's Details:</h3>
			</td>

		</tr>
		<tr>
				<td >Name*: </td>
				<td> <input type="text" name="" placeholder=""> </td>
			</tr>

		<tr>
				<td >Country*:</td>
				<td> 
					<select name="">
						<option>Bangladesh</option>
						<option>India</option>
						<option>China</option>
						<option>France</option>
						<option>Nepal</option>
						<option>Italy</option>
					</select> 
				</td>
			</tr>
		<tr>
			<td><input type="checkbox" name=""> Same as Parmanent Address</td>
		</tr>
		<tr>
			<td><input type="checkbox" name=""> Same as Present Address</td>
		</tr>
		<tr> <!-- Dropdown box-->
				<td >Village/House :</td>
				<td> 
					<input type="text" name="v" placeholder=""> 
				</td>
			</tr>

			<tr> <!-- Dropdown box-->
				<td>Road/Block/Sector:</td>
				<td> 
					<input type="text" name="bc" placeholder=""> 
				</td>
			</tr>

			<tr>
				<td>District:</td>
				<td>
				 <select>
				 	<option>-Select-</option>
				 	<option>Barishal</option>
				 	<option>Sylhet</option>
				 	<option>Dhaka</option>
				 	<option>Chittagong</option>
				 	<option>Khulna</option>
				 	<option>Rangpur</option>
				 </select>
				</td>
			</tr>

			<tr>
				<td>Police Station:</td>
				<td>
				 <select>
				 	<option>-Select-</option>
				 	<option>Sreenagar</option>
				 	<option>Dhanmondi</option>
				 	<option>Shutrapur</option>
				 	<option>Borolekha</option>
				 	<option>Fatulla</option>
				 </select>
				</td>
			</tr>

			<tr>
				<td>Post Office:</td>
				<td>
				 <select>
				 	<option>-Select-</option>
				 	<option>Sreenagar</option>
				 	<option>Dhanmondi</option>
				 	<option>Shutrapur</option>
				 	<option>Borolekha</option>
				 	<option>Fatulla</option>
				 </select>
				</td>
			</tr>

			<tr> <!-- Dropdown box-->
				<td >Contact No:</td>
				<td> 
					<input type="text" name="" placeholder=""> 
				</td>
			</tr>

			<tr> <!-- Dropdown box-->
				<td >Email:</td>
				<td> 
					<input type="text" name="" placeholder=""> 
				</td>
			</tr>

			<tr>
				<td >Relationship Status</td>
				<td> 
					<select>
						<option>-Select-</option>
						<option>Brother</option>
						<option>Sister</option>
						<option>Aunt</option>
						<option>Uncle</option>
					</select> 
				</td>
			</tr>

			<tr> 
				<td colspan="7"></td>
				<td >
				<input type="submit" name="" value="Previous Page"> 
				<input type="submit" name="" value="Save & Next"> 
				</td>
			</tr>


			

	</table>

</form>


</body>
</html>