<?php

if(isset($_POST['submit']))
{

    $applicant_name = $_POST['apli_name'];
    $first_name = $_POST['fn'];
    $sur_name = $_POST['sn'];
    $father_name = $_POST['fathern'];
    $mother_name = $_POST['mothern'];
    $spouse_name = $_POST['spousen'];
    $birth = $_POST['dob'];
    $birth_id = $_POST['birthid'];
    $national_id = $_POST['nid'];
    $tax_id = $_POST['taxid'];
    $email_id = $_POST['email'];

    $present_village_house = $_POST['pvh'];
    $present_road_block_sector = $_POST['prbs'];
    $present_police_station = $_POST['pps'];
    $present_post_office = $_POST['ppo'];

    $permanent_village_house = $_POST['permvh'];
    $permanent_road_block_sector = $_POST['permrbs'];
    $permanent_police_station = $_POST['permps'];
    $permanent_post_office = $_POST['permpo'];

    if (empty($applicant_name)) 
    {
        $msg = "please enter applicant name";       
    }
    elseif (empty($first_name)) 
    {
        $msg = "please enter first name";       
    }
    elseif (empty($sur_name)) 
    {
        $msg = "please enter surname";      
    }
    elseif (empty($father_name)) 
    {
        $msg = "please enter father name";      
    }
    elseif (empty($mother_name)) 
    {
        $msg = "please enter mother name";      
    }
    elseif (empty($spouse_name)) 
    {
        $msg = "please enter spouse name";       
    }
    elseif (empty($birth)) 
    {
        $msg = "please enter date of birth";        
    }
    elseif (empty($birth_id)) 
    {
        $msg = "please enter birth id";     
    }
    elseif (empty($national_id)) 
    {
        $msg = "please enter national id";      
    }
    elseif (empty($tax_id)) 
    {
        $msg = "please enter tax id";       
    }
    elseif (empty($email_id)) 
    {
        $msg = "please enter email id";     
    }
    elseif (!filter_var($email_id, FILTER_VALIDATE_EMAIL)) 
    {
        $msg = "please enter a valid email id";     
    }

    elseif (empty($present_village_house)) 
    {
        $msg = "please enter present_village_house";        
    }
    elseif (empty($present_road_block_sector)) 
    {
        $msg = "please enter present_road_block_sector";    
    }
    elseif (empty($present_police_station)) 
    {
        $msg = "please enter present_police_station";       
    }
    elseif (empty($present_post_office)) 
    {
        $msg = "please enter present_post_office";      
    }


    elseif (empty($permanent_village_house)) 
    {
        $msg = "please enter permanent_village_house";      
    }
    elseif (empty($permanent_road_block_sector)) 
    {
        $msg = "please enter permanent_road_block_sector";  
    }
    elseif (empty($permanent_police_station)) 
    {
        $msg = "please enter permanent_police_station";     
    }
    elseif (empty($permanent_post_office)) 
    {
        $msg = "please enter permanent_post_office";        
    }
}
?>
<?php
    if(isset($msg)){
        echo $msg."<br>";
    }
?>


<?php

    


    function sanitize_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    
    
    $applicant_name=sanitize_input($_POST['apli_name']);
    $first_name=sanitize_input($_POST['fn']);
    $sur_name=sanitize_input($_POST['sn']);
    $father_name=sanitize_input($_POST['fathern']);
    $mother_name=sanitize_input($_POST['mothern']);
    $spouse_name=sanitize_input($_POST['spousen']);
    $birth=sanitize_input($_POST['dob']);
    $birth_id=sanitize_input($_POST['birthid']);
    $national_id=sanitize_input($_POST['nid']);
    $tax_id=sanitize_input($_POST['taxid']);
    $email_id=sanitize_input($_POST['email']);
    $present_village_house=sanitize_input($_POST['pvh']);
    $present_road_block_sector=sanitize_input($_POST['prbs']);
    $present_police_station=sanitize_input($_POST['pps']);
    $present_post_office=sanitize_input($_POST['ppo']);
    $permanent_village_house=sanitize_input($_POST['permvh']);
    $permanent_road_block_sector=sanitize_input($_POST['permrbs']);
    $permanent_police_station=sanitize_input($_POST['permps']);
    $permanent_post_office=sanitize_input($_POST['permpo']);

    echo "Personal Information Summary:<br><br>";
    echo "Name of applicant:";
    echo $applicant_name."<br>";
    echo "First Name:";
    echo $first_name."<br>";
    echo "Last Name:";
    echo $sur_name."<br>";
    echo "Father's Name:";
    echo $father_name."<br>";
    echo "Mother's Name:";
    echo $mother_name."<br>";
    echo "Spouse's Name:";
    echo $spouse_name."<br>";
    echo $birth."<br>";
    echo "Birth Id No.:";
    echo $birth_id."<br>";
    echo "National ID No.:";
    echo $national_id."<br>";
    echo $tax_id."<br>";
    echo $email_id."<br>";
    echo "Present Address:";
    echo $present_village_house;
    echo ",";
    echo $present_road_block_sector;
    echo ",";
    echo $present_police_station;
    echo ",";
    echo $present_post_office."<br>";
    echo "Parmanent Address:";
    echo $permanent_village_house;
    echo ",";
    echo $permanent_road_block_sector;
    echo ",";
    echo $permanent_police_station;
    echo ",";
    echo $permanent_post_office."<br>";    
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your DATA</title>
</head>
<body>
    <form action="second.php">
        <tr> <!-- Submit/register & reset button-->
            <td colspan="2"> 
            <input type="submit" name="submit" value="Previous"> 
            <input type="submit" name="submit" value="SAVE & NEXT"> 
            </td>
        </tr>
    </form>

</body>
</html>